const express = require("express");
const mysql = require("mysql");
const bodyParser = require("body-parser");
const app = express();
const port = 3000;
app.use(express.json());
app.use(express.static(__dirname));
const dbConfig = {
  host: "localhost",
  user: "root",
  password: "",
  database: "library",
};
const session = require('express-session');

app.use(session({
  secret: 'sanyam',  
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } 
}));

app.use(bodyParser.urlencoded({ extended: true }));

app.get("/", (req, res) => {
  res.sendFile(__dirname + "/main_index.html");
});

app.post("/submit", async (req, res) => {
    const { username, password } = req.body;
    try {
      const connection = mysql.createConnection(dbConfig);
      connection.connect();
      const sql = "SELECT * FROM user_details WHERE username = ? AND password = ?";
      const values = [username, password];
      connection.query(sql, values, (error, results) => {
        if (error) throw error;
        if (results.length === 1) {
          req.session.loggedin = true;
          req.session.username = username;
  
          res.sendFile(__dirname + "/main_index.html");
        } else {
          res.send("Invalid user credentials");
        }
      });
      connection.end();
    } catch (error) {
      console.error("Error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });
  
app.get("/other2", (req, res) => {
  res.sendFile(__dirname + "/index.html");
});

app.post("/submit2", async (req, res) => {
  const { username, email, password } = req.body;
  try {
    const connection = mysql.createConnection(dbConfig);
    connection.connect();
    const checkUsernameSql =
      "SELECT COUNT(*) AS count FROM user_details WHERE username = ?";
    connection.query(checkUsernameSql, [username], (checkError, result) => {
      if (checkError) {
        console.error("Error checking username:", checkError);
        res.status(500).json({ error: "Internal server error" });
      } else {
        const usernameExists = result[0].count > 0;
        if (usernameExists) {
          connection.end(); 
          res.status(409).json({ error: "Username already exists" });
        } else {
          const insertSql =
            "INSERT INTO user_details (username, email, password) VALUES (?, ?, ?)";
          const values = [username, email, password];
          connection.query(insertSql, values, (insertError) => {
            if (insertError) {
              console.error("Error inserting user:", insertError);
              res.status(500).json({ error: "Internal server error" });
            } else {
              console.log("User registered successfully");
              connection.end(); 
              res.sendFile(__dirname + "/main_index.html");
            }
          });
        }
      }
    });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.get("/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        console.error("Error logging out:", err);
        res.status(500).json({ error: "Internal server error" });
      } else {
        res.redirect("/");  
      }
    });
  });

  app.get("/check-login", (req, res) => {
    if (req.session.loggedin) {
      res.json({ loggedin: true });
    } else {
      res.json({ loggedin: false });
    }
  });

  function redirectIfNotLoggedIn(req, res, next) {
    if (!req.session.loggedin) {
      return res.redirect("/");
    }
    next();
  }
  
app.get("/admin_main", redirectIfNotLoggedIn, (req, res) => {
    res.sendFile(__dirname + "/admin_main.html");
  });
  
app.get("/other3", (req, res) => {
  res.sendFile(__dirname + "/admin_login.html");
});

app.post("/submit3", async (req, res) => {
  try {
    const connection = mysql.createConnection(dbConfig);
    connection.connect();
    const sql =
      'SELECT * FROM admin WHERE username = "admin" AND password = "admin@123"';
    connection.query(sql, (error, results) => {
      if (error) throw error;
      if (results.length === 1) {
        res.sendFile(__dirname + "/admin_main.html");
      } else {
        res.send("Invalid admin credentials");
      }
    });
    connection.end();
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.get("/other4", (req, res) => {
  res.sendFile(__dirname + "/view.html");
});

app.post("/submit4", async (req, res) => {
  try {
    const connection = mysql.createConnection(dbConfig);
    connection.connect();
    const sql = "SELECT * FROM user_details";
    connection.query(sql, (error, results) => {
      if (error) throw error;
      if (results.length > 0) {
        res.send(results);
      } else {
        res.send("Database is Empty");
      }
    });
    connection.end();
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.get("/other5", (req, res) => {
  res.sendFile(__dirname + "/delete.html");
});

app.post("/submit5", async (req, res) => {
  const { username } = req.body;
  try {
    const connection = mysql.createConnection(dbConfig);
    connection.connect();
    const sql = "DELETE FROM user_details WHERE username = ?";
    const values = [username];
    connection.query(sql, values, (error, results) => {
      if (error) {
        console.error("Error:", error);
        res.status(500).json({ error: "Internal server error" });
      } else if (results.affectedRows === 1) {
        res.send("User successfully deleted");
      } else {
        res.send("User doesn't exist");
      }
    });
    connection.end();
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

function check(password) {
  var pattern = /[@_&*^#%@!]/;
  return pattern.test(password);
}
function checkuppercase(password) {
  var temp = password;
  var flag = false;
  for (var i = 0; i < password.length; i++) {
    if (temp[i].toUpperCase() === password[i]) {
      flag = true;
    }
  }
  return flag;
}
function submitForm(username, password) {
  const data = { username, password };

  fetch("/submit", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })
    .then((response) => response.json())
    .then((result) => {
      console.log(result);
    })
    .catch((error) => {
      console.error("Error:", error);
    });
}
function checkemail(email) {
  var atposition = email.indexOf("@");
  var dotposition = email.lastIndexOf(".");
  if (
    atposition < 1 ||
    dotposition < atposition + 2 ||
    dotposition + 2 >= email.length
  ) {
    return false;
  } else {
    return true;
  }
}

function validate_Insert() {
  var username = document.getElementById("username").value;
  var password = document.getElementById("password").value;
  var email = document.getElementById("email").value;

  if (username != "" && password != "" && email != "") {
    if (check(password) && checkuppercase(password) && checkemail(email)) {
      alert("Signup successful!");
      submitForm(username, password);
    } else {
      alert(
        "Password must contain a special character and at least one uppercase letter."
      );
    }
  } else {
    alert("Login failed. Please check your username and password.");
  }
}

document.addEventListener("DOMContentLoaded", function () {
  const loginForm = document.getElementById("signupform");

  loginForm.addEventListener("submit3", function (event) {
    const passwordInput = document.querySelector('input[name="password"]');
    const password = passwordInput.value;

    const specialCharRegex = /[!@#$%^&*()_+{}\[\]:;<>,.?~\\-]/;
    const uppercaseRegex = /[A-Z]/;

    if (!specialCharRegex.test(password) || !uppercaseRegex.test(password)) {
      event.preventDefault();
      alert(
        "Password must contain at least one special character and one uppercase letter."
      );
    }
  });
});
